export type NSDictionary = ObjC.Object | any;
export type NSMutableDictionary = ObjC.Object | any;
export type NSString = ObjC.Object | any;
export type NSFileManager = ObjC.Object | any;
export type NSBundle = ObjC.Object | any;
export type NSUserDefaults = ObjC.Object | any;
export type NSHTTPCookieStorage = ObjC.Object | any;
export type NSURLCredentialStorage = ObjC.Object | any;
export type NSArray = ObjC.Object | any;
export type NSData = ObjC.Object | any;

export type CFDictionaryRef = any;
export type CFTypeRef = any;
