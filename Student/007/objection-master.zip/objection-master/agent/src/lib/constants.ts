export enum DeviceType {
  IOS = "ios",
  ANDROID = "android",
  UNKNOWN = "unknown",
}
