export const ping = (): boolean => true;
