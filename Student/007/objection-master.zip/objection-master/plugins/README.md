# plugins

`objection` has the ability to sideload external plugins. This directory contains a few sample plugins that you could use to kickstart developing your own!
