# objection stetho plugin

This plugin should sideload Facebook's Stetho [1], loaded as a plugin in objection.

[1] [http://facebook.github.io/stetho/](http://facebook.github.io/stetho/)  
