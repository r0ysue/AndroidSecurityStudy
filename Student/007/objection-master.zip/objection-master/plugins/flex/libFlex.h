#import <Foundation/Foundation.h>

@interface libFlex : NSObject

- (id)init;
- (void)logSomething:(NSString *)something;
- (void)flexUp;

@end
