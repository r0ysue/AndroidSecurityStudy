rpc.exports = {
  getVersion: function () {
    return Frida.version;
  }
}
