# OWASP MAS Crackmes

[![Build Status](https://travis-ci.org/commjoen/uncrackable_app.svg?branch=master)](https://travis-ci.org/commjoen/uncrackable_app)

<img width="180px" align="right" style="float: right; border-radius: 5px;" src="https://raw.githubusercontent.com/OWASP/owasp-mastg/master/Document/Images/Other/uncrackable-logo.png">

This repo contains the source code for the [OWASP MAS Crackmes](https://mas.owasp.org/crackmes/).

Welcome to the MAS Crackmes aka. UnCrackable Apps, a collection of mobile reverse engineering challenges. These challenges are used as examples throughout the OWASP MASTG. Of course, you can also solve them for fun.

<br>

⚠️ **SPOLER ALERT:** Use this repo responsibly. If you read the source code, you will spoil the fun you'll have _cracking_ the actual crackmes ;-)
