//
//  maxpower.h
//  UnDebuggable
//
//  Created by Bernhard Mueller on 1/26/17.
//  Copyright © 2017 Bernhard Mueller. All rights reserved.
//

#ifndef maxpower_h
#define maxpower_h

#include <stdio.h>

char *do_it(void);

#endif /* maxpower_h */
